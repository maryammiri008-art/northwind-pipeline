package plugin

import (
	"context"
	"crypto/tls"
	"crypto/x509"
	"database/sql"
	"encoding/json"
	"errors"
	"fmt"
	"net"
	"regexp"
	"strconv"
	"strings"
	"time"

	"github.com/ClickHouse/clickhouse-go/v2"
	"github.com/grafana/clickhouse-datasource/pkg/converters"
	"github.com/grafana/clickhouse-datasource/pkg/macros"
	"github.com/grafana/grafana-plugin-sdk-go/backend"
	sdkproxy "github.com/grafana/grafana-plugin-sdk-go/backend/proxy"
	"github.com/grafana/grafana-plugin-sdk-go/backend/tracing"
	"github.com/grafana/grafana-plugin-sdk-go/build/buildinfo"
	"github.com/grafana/grafana-plugin-sdk-go/data"
	"github.com/grafana/grafana-plugin-sdk-go/data/sqlutil"
	"github.com/grafana/sqlds/v5"
	"go.opentelemetry.io/otel/attribute"
	"go.opentelemetry.io/otel/trace"
	"golang.org/x/net/proxy"
)

type grafanaHeadersKeyType struct{}

var grafanaHeadersKey = grafanaHeadersKeyType{}

type grafanaHeaders struct {
	DashboardUID string
	PanelID      string
	RuleUID      string
}

// Clickhouse defines how to connect to a Clickhouse datasource
type Clickhouse struct{}

// getTLSConfig returns tlsConfig from settings
// logic reused from https://github.com/grafana/grafana/blob/615c153b3a2e4d80cff263e67424af6edb992211/pkg/models/datasource_cache.go#L211
func getTLSConfig(settings Settings) (*tls.Config, error) {
	tlsConfig := &tls.Config{
		InsecureSkipVerify: settings.InsecureSkipVerify,
		ServerName:         settings.Host,
	}
	if settings.TlsClientAuth || settings.TlsAuthWithCACert {
		if settings.TlsAuthWithCACert && len(settings.TlsCACert) > 0 {
			caPool := x509.NewCertPool()
			if ok := caPool.AppendCertsFromPEM([]byte(settings.TlsCACert)); !ok {
				return nil, backend.DownstreamError(ErrorInvalidCACertificate)
			}
			tlsConfig.RootCAs = caPool
		}
		if settings.TlsClientAuth {
			cert, err := tls.X509KeyPair([]byte(settings.TlsClientCert), []byte(settings.TlsClientKey))
			if err != nil {
				return nil, err
			}
			tlsConfig.Certificates = []tls.Certificate{cert}
		}
	}
	return tlsConfig, nil
}

// getPDCDialContext returns a dialer function for creating a connection to PDC if a secure SOCKS proxy is enabled.
//
// clickhouse-go applies Options.TLS only on its own dial path, and skips that
// path once Options.DialContext is set. The native protocol therefore needs
// this dialer to complete the TLS handshake itself. HTTP does not: net/http
// applies Transport.TLSClientConfig over the dialed connection, and a second
// handshake breaks it.
func getPDCDialContext(settings Settings, tlsConfig *tls.Config, protocol clickhouse.Protocol) (func(context.Context, string) (net.Conn, error), error) {
	p := sdkproxy.New(settings.ProxyOptions)

	if !p.SecureSocksProxyEnabled() {
		return nil, nil
	}

	dialer, err := p.NewSecureSocksProxyContextDialer()
	if err != nil {
		return nil, err
	}

	contextDialer, ok := dialer.(proxy.ContextDialer)
	if !ok {
		return nil, errors.New("unable to cast SOCKS proxy dialer to context proxy dialer")
	}

	return proxyDialContext(contextDialer, tlsConfig, protocol), nil
}

// proxyDialContext routes connections through base, adding TLS for the native protocol.
func proxyDialContext(base proxy.ContextDialer, tlsConfig *tls.Config, protocol clickhouse.Protocol) func(context.Context, string) (net.Conn, error) {
	wrapTLS := tlsConfig != nil && protocol == clickhouse.Native

	return func(ctx context.Context, addr string) (net.Conn, error) {
		conn, err := base.DialContext(ctx, "tcp", addr)
		if err != nil || !wrapTLS {
			return conn, err
		}

		// tls.Client does not derive the SNI name from the address, unlike
		// tls.Dial, so an empty ServerName fails verification. The config is
		// cloned because clickhouse.Options.TLS shares the same value.
		cfg := tlsConfig.Clone()
		if cfg.ServerName == "" {
			host, _, splitErr := net.SplitHostPort(addr)
			if splitErr != nil {
				host = addr
			}
			cfg.ServerName = host
		}

		tlsConn := tls.Client(conn, cfg)
		if err := tlsConn.HandshakeContext(ctx); err != nil {
			_ = conn.Close()
			return nil, fmt.Errorf("TLS handshake through the secure SOCKS proxy failed: %w", err)
		}
		return tlsConn, nil
	}
}

func getClientInfoProducts(ctx context.Context) (products []struct{ Name, Version string }) {
	version := backend.UserAgentFromContext(ctx).GrafanaVersion()

	if version != "" {
		products = append(products, struct{ Name, Version string }{
			Name:    "grafana",
			Version: version,
		})
	}

	if info, err := buildinfo.GetBuildInfo(); err == nil {
		products = append(products, struct{ Name, Version string }{
			Name:    "clickhouse-datasource",
			Version: info.Version,
		})
	}

	return products
}

func CheckMinServerVersion(conn *sql.DB, major, minor, patch uint64) (bool, error) {
	var version struct {
		Major uint64
		Minor uint64
		Patch uint64
	}
	var res string
	if err := conn.QueryRow("SELECT version()").Scan(&res); err != nil {
		return false, err
	}
	for i, v := range strings.Split(res, ".") {
		switch i {
		case 0:
			version.Major, _ = strconv.ParseUint(v, 10, 64)
		case 1:
			version.Minor, _ = strconv.ParseUint(v, 10, 64)
		case 2:
			version.Patch, _ = strconv.ParseUint(v, 10, 64)
		}
	}
	if version.Major < major || (version.Major == major && version.Minor < minor) ||
		(version.Major == major && version.Minor == minor && version.Patch < patch) {
		return false, nil
	}
	return true, nil
}

// resolveJWTAuth builds the ClickHouse Auth and GetJWT callback when JWT
// authentication is enabled. The Bearer token is removed from httpHeaders
// (mutated in-place) and returned via the GetJWT callback instead.
func resolveJWTAuth(settings Settings, httpHeaders map[string]string) (clickhouse.Auth, clickhouse.GetJWTFunc) {
	auth := clickhouse.Auth{
		Database: settings.DefaultDatabase,
		Username: settings.Username,
		Password: settings.Password,
	}

	authHeader := httpHeaders[backend.OAuthIdentityTokenHeaderName]
	if !settings.OAuthPassThru || authHeader == "" {
		return auth, nil
	}

	delete(httpHeaders, backend.OAuthIdentityTokenHeaderName)
	token := strings.TrimPrefix(authHeader, "Bearer ")
	return clickhouse.Auth{Database: settings.DefaultDatabase},
		func(context.Context) (string, error) { return token, nil }
}

func wrapCategorizedConnectionError(err error) error {
	category := CategorizeConnectionError(err)
	backend.Logger.Error("failed to create ClickHouse client", "error_category", string(category))
	if category == ConnectionErrorCategoryAuth {
		if hint := authErrorHint(err); hint != "" {
			return backend.DownstreamError(fmt.Errorf("[%s] %w (%s)", category, err, hint))
		}
	}
	return backend.DownstreamError(fmt.Errorf("[%s] %w", category, err))
}

func buildClickHouseOptions(ctx context.Context, settings Settings, message json.RawMessage) (*clickhouse.Options, error) {
	var tlsConfig *tls.Config
	var err error
	if settings.TlsAuthWithCACert || settings.TlsClientAuth {
		tlsConfig, err = getTLSConfig(settings)
		if err != nil {
			return nil, wrapCategorizedConnectionError(err)
		}
	} else if settings.Secure {
		tlsConfig = &tls.Config{
			InsecureSkipVerify: settings.InsecureSkipVerify,
		}
	}

	t, err := strconv.Atoi(settings.DialTimeout)
	if err != nil {
		return nil, backend.DownstreamError(fmt.Errorf("invalid timeout: %s", settings.DialTimeout))
	}
	qt, err := strconv.Atoi(settings.QueryTimeout)
	if err != nil {
		return nil, backend.DownstreamError(fmt.Errorf("invalid query timeout: %s", settings.QueryTimeout))
	}

	protocol := clickhouse.Native
	if settings.Protocol == "http" {
		protocol = clickhouse.HTTP
	}

	compression := clickhouse.CompressionLZ4
	if protocol == clickhouse.HTTP {
		compression = clickhouse.CompressionGZIP
	}

	customSettings := make(clickhouse.Settings)
	if settings.CustomSettings != nil {
		for _, setting := range settings.CustomSettings {
			customSettings[setting.Setting] = setting.Value
		}
	}

	if settings.RowLimit != 0 && settings.EnableRowLimit {
		customSettings["limit"] = settings.RowLimit
	}

	httpHeaders, err := extractForwardedHeadersFromMessage(message)
	if err != nil {
		return nil, err
	}

	// merge settings.HttpHeaders with message httpHeaders
	for k, v := range settings.HttpHeaders {
		httpHeaders[k] = v
	}

	if settings.OAuthPassThru && tlsConfig == nil {
		return nil, backend.DownstreamError(fmt.Errorf("JWT authentication requires a secure (TLS) connection"))
	}

	// Forwarding a real user's token over a connection whose server
	// certificate is not verified exposes the token to interception. This is a
	// higher bar than a shared service credential, so reject the combination.
	if settings.OAuthPassThru && settings.InsecureSkipVerify {
		return nil, backend.DownstreamError(fmt.Errorf("the \"Forward OAuth Identity\" and \"Skip TLS Verify\" options cannot be combined: forwarding a user token over an unverified TLS connection would expose it to interception"))
	}

	// When Forward OAuth Identity is enabled, a data query (message != nil)
	// that arrives without a forwarded user token is a backend query with no
	// user to attribute it to — typically alert rule evaluation. Health checks
	// and schema introspection pass a nil message and always fall back, since
	// no user token is ever available for them.
	if settings.OAuthPassThru && message != nil && httpHeaders[backend.OAuthIdentityTokenHeaderName] == "" {
		if !settings.OAuthPassThruAllowFallback {
			return nil, backend.DownstreamError(fmt.Errorf(
				"this query carries no user identity but \"Forward OAuth Identity\" is enabled; " +
					"it is running outside a user session (for example, an alert rule). Enable " +
					"\"Allow service account fallback\" on the data source to let these queries " +
					"run with the configured username/password, or ensure the request forwards a user OAuth token"))
		}
		// Fallback is opt-in and exercised: warn so the privilege divergence is
		// not silent. These queries run as the shared service account and are
		// not subject to the per-user row policies or quotas that OAuth
		// pass-through enforces for interactive queries.
		backend.Logger.Warn("Forward OAuth Identity: query has no forwarded user identity; " +
			"falling back to the configured username/password (service account)")
	}

	auth, getJWT := resolveJWTAuth(settings, httpHeaders)

	opts := &clickhouse.Options{
		Addr: []string{fmt.Sprintf("%s:%d", settings.Host, settings.Port)},
		Auth: auth,
		ClientInfo: clickhouse.ClientInfo{
			Products: getClientInfoProducts(ctx),
		},
		Compression: &clickhouse.Compression{
			Method: compression,
		},
		DialTimeout: time.Duration(t) * time.Second,
		GetJWT:      getJWT,
		HttpHeaders: httpHeaders,
		HttpUrlPath: settings.Path,
		Protocol:    protocol,
		ReadTimeout: time.Duration(qt) * time.Second,
		Settings:    customSettings,
		TLS:         tlsConfig,
	}

	// dialCtx is used to create a connection to PDC, if it is enabled above
	dialCtx, err := getPDCDialContext(settings, tlsConfig, protocol)
	if err != nil {
		return nil, err
	}
	if dialCtx != nil {
		opts.DialContext = dialCtx
	}

	return opts, nil
}

// Connect opens a sql.DB connection using datasource settings
func (h *Clickhouse) Connect(
	ctx context.Context,
	config backend.DataSourceInstanceSettings,
	message json.RawMessage,
) (*sql.DB, error) {
	ctx, span := tracing.DefaultTracer().Start(ctx, "clickhouse connect", trace.WithAttributes(
		attribute.String("db.system", "clickhouse"),
	))

	defer span.End()

	settings, err := LoadSettings(ctx, config)
	if err != nil {
		return nil, wrapCategorizedConnectionError(err)
	}

	opts, err := buildClickHouseOptions(ctx, settings, message)
	if err != nil {
		return nil, err
	}

	ctx, cancel := context.WithTimeout(ctx, opts.DialTimeout)
	defer cancel()

	db := clickhouse.OpenDB(opts)

	// Set connection pool settings
	if i, err := strconv.Atoi(settings.ConnMaxLifetime); err == nil {
		db.SetConnMaxLifetime(time.Duration(i) * time.Minute)
	}
	if i, err := strconv.Atoi(settings.MaxIdleConns); err == nil {
		db.SetMaxIdleConns(i)
	}
	if i, err := strconv.Atoi(settings.MaxOpenConns); err == nil {
		db.SetMaxOpenConns(i)
	}

	select {
	case <-ctx.Done():
		return nil, fmt.Errorf("the operation was cancelled before starting: %w", ctx.Err())
	default:
		// proceed
	}

	// `sqlds` normally calls `db.PingContext()` to check if the connection is alive,
	// however, as ClickHouse returns its own non-standard `Exception` type, we need
	// to handle it here so that we can categorize and surface the error correctly.
	if err := db.PingContext(ctx); err != nil {
		if ctx.Err() != nil {
			return nil, fmt.Errorf("the operation was cancelled during execution: %w", ctx.Err())
		}

		return nil, wrapCategorizedConnectionError(err)
	}

	// Honor the (nil-resource-on-error) contract so callers can rely on
	// `if err != nil { return err }` without leaking the *sql.DB.
	if err := settings.isValid(); err != nil {
		_ = db.Close()
		return nil, err
	}
	return db, nil
}

// Converters defines list of data type converters
func (h *Clickhouse) Converters() []sqlutil.Converter {
	return converters.ClickhouseConverters
}

// Macros returns an empty macro map. ClickHouse macros are expanded by the
// macropro-backed sqlds.Interpolator installed in NewDatasource, which
// replaces sqlds's sqlutil.Interpolate pipeline entirely, so this map is
// never consulted on the query path. macropro.DefaultMacros is already
// merged into macros.ClickHouseMacros, so nothing is lost by leaving it
// empty.
func (h *Clickhouse) Macros() sqlds.Macros {
	return sqlds.Macros{}
}

// MutateQueryError marks ClickHouse errors as downstream errors
func (h *Clickhouse) MutateQueryError(err error) backend.ErrorWithSource {
	// Check if any error in the error chain (including multi-errors) is a clickhouse.Exception
	if containsClickHouseException(err) {
		return backend.NewErrorWithSource(err, backend.ErrorSourceDownstream)
	}
	return backend.NewErrorWithSource(err, backend.DefaultErrorSource)
}

// containsClickHouseException checks if err or any error in its chain is a clickhouse.Exception
// It also handles errors wrapped in HTTP response bodies
func containsClickHouseException(err error) bool {
	if err == nil {
		return false
	}

	// Check if the current error is directly a clickhouse.Exception
	var wrappedException *clickhouse.Exception
	if errors.As(err, &wrappedException) {
		return true
	}

	errStr := err.Error()

	// Look for common ClickHouse error patterns in response bodies
	if strings.Contains(errStr, "DB::Exception") {
		return true
	}

	// Catch legacy ClickHouse HTTP error format.
	// This is more general than the above and we attempt the DB::Exception catch first
	// as those errors also contain this pattern.
	// We're only catching 4xx errors for now but we can expand to 5xx if needed.
	matcher, _ := regexp.Compile(`(\[HTTP 4\d\d\])`)
	if matcher.MatchString(errStr) {
		return true
	}

	// Check for multiple wrapped errors (e.g., from errors.Join)
	type multiError interface {
		Unwrap() []error
	}

	if u, ok := err.(multiError); ok {
		for _, e := range u.Unwrap() {
			if containsClickHouseException(e) {
				return true
			}
		}
	}

	return false
}

func (h *Clickhouse) Settings(ctx context.Context, config backend.DataSourceInstanceSettings) sqlds.DriverSettings {
	settings, err := LoadSettings(ctx, config)
	timeout := 60
	if err == nil {
		t, err := strconv.Atoi(settings.QueryTimeout)
		if err == nil {
			timeout = t
		}
	}
	return sqlds.DriverSettings{
		Timeout: time.Second * time.Duration(timeout),
		FillMode: &data.FillMissing{
			Mode: data.FillModeNull,
		},
		ForwardHeaders:  settings.ForwardGrafanaHeaders || settings.OAuthPassThru,
		RowCapacityHint: settings.RowCapacityHint,
	}
}

// MutateQueryData extracts Grafana contextual headers from the request and
// stores them in the context for ClickHouse query metadata injection.
func (h *Clickhouse) MutateQueryData(
	ctx context.Context,
	req *backend.QueryDataRequest,
) (context.Context, *backend.QueryDataRequest) {
	headers := req.GetHTTPHeaders()
	gh := grafanaHeaders{
		DashboardUID: headers.Get("X-Dashboard-Uid"),
		PanelID:      headers.Get("X-Panel-Id"),
		RuleUID:      headers.Get("X-Rule-Uid"),
	}
	if gh.DashboardUID != "" || gh.PanelID != "" || gh.RuleUID != "" {
		ctx = context.WithValue(ctx, grafanaHeadersKey, gh)
	}

	injectGrafanaUserHeader(ctx, req)

	return ctx, req
}

// injectGrafanaUserHeader populates X-Grafana-User from the request's user
// context when "Forward Grafana HTTP Headers" is enabled. Grafana's
// `dataproxy.send_user_header` setting only adds the header to the proxy
// path (core HTTP datasources); plugin-initiated connections never see it,
// so downstream ClickHouse loses the user attribution that operators expect
// when the toggle is on. See #1451.
func injectGrafanaUserHeader(ctx context.Context, req *backend.QueryDataRequest) {
	if req == nil || req.PluginContext.DataSourceInstanceSettings == nil {
		return
	}
	if req.GetHTTPHeader("X-Grafana-User") != "" {
		return
	}
	settings, err := LoadSettings(ctx, *req.PluginContext.DataSourceInstanceSettings)
	if err != nil || !settings.ForwardGrafanaHeaders {
		return
	}
	user := backend.UserFromContext(ctx)
	if user == nil || user.Login == "" {
		return
	}
	req.SetHTTPHeader("X-Grafana-User", user.Login)
}

// interpolateMacros is the sqlds.Interpolator installed by NewDatasource. It
// replaces sqlds's default sqlutil.Interpolate pipeline with macropro, so
// macropro owns macro parsing end-to-end and handlers receive the fully
// parsed query — including Table and Column, which the previous
// MutateQueryData pre-expansion never carried. Expansion errors return
// straight to the query response rather than being smuggled through a
// throwIf() rewrite that failed at execution time.
//
// Every error is wrapped as a downstream error: interpolation failures
// originate from the user's query text (bad macro arguments, missing
// table/column context, parse errors), never from a plugin bug. Our own
// handlers already wrap backend.DownstreamError, but macropro's default
// handlers ($__table, $__column) return plain errors, and sqlds only
// downstream-classifies bad-argument-count and bracket errors on its own —
// so without this wrap those would be miscounted as plugin errors.
func interpolateMacros(_ context.Context, query *sqlutil.Query, _ json.RawMessage) (string, error) {
	sql, err := macros.Interpolate(query.RawSQL, query)
	if err != nil {
		return "", backend.DownstreamError(err)
	}
	return sql, nil
}

func (h *Clickhouse) MutateQuery(ctx context.Context, req backend.DataQuery) (context.Context, backend.DataQuery) {
	ctx, span := tracing.DefaultTracer().Start(ctx, "clickhouse mutate_query", trace.WithAttributes(
		attribute.String("db.system", "clickhouse"),
	))

	defer span.End()

	comments := make([]string, 0, 4)

	if user := backend.UserFromContext(ctx); user != nil {
		comments = append(comments, "grafana_user:"+user.Login)
	}

	if gh, ok := ctx.Value(grafanaHeadersKey).(grafanaHeaders); ok {
		if gh.DashboardUID != "" {
			comments = append(comments, "grafana_dashboard:"+gh.DashboardUID)
		}
		if gh.PanelID != "" {
			comments = append(comments, "grafana_panel:"+gh.PanelID)
		}
		if gh.RuleUID != "" {
			comments = append(comments, "grafana_rule:"+gh.RuleUID)
		}
	}

	if len(comments) > 0 {
		ctx = clickhouse.Context(ctx, clickhouse.WithClientInfo(clickhouse.ClientInfo{
			Products: nil,
			Comment:  comments,
		}))
	}

	var dataQuery struct {
		Meta struct {
			TimeZone string `json:"timezone"`
		} `json:"meta"`
		Format int `json:"format"`
	}

	if err := json.Unmarshal(req.JSON, &dataQuery); err != nil {
		return ctx, req
	}

	if dataQuery.Meta.TimeZone == "" {
		return ctx, req
	}

	loc, _ := time.LoadLocation(dataQuery.Meta.TimeZone)
	return clickhouse.Context(ctx, clickhouse.WithUserLocation(loc)), req
}

// MutateResponse converts fields of type FieldTypeNullableJSON to string,
// except for specific visualizations (traces, tables, and logs).
func (h *Clickhouse) MutateResponse(ctx context.Context, res data.Frames) (data.Frames, error) {
	_, span := tracing.DefaultTracer().Start(ctx, "clickhouse mutate_response", trace.WithAttributes(
		attribute.String("db.system", "clickhouse"),
	))

	defer span.End()

	for _, frame := range res {
		if frame.Meta.PreferredVisualization == data.VisTypeLogs {
			err := mergeOpenTelemetryLabels(frame)
			if err != nil {
				return nil, err
			}
		}

		if shouldConvertFields(frame.Meta.PreferredVisualization) {
			if err := convertNullableJSONFields(frame); err != nil {
				return res, err
			}
		}
	}
	return res, nil
}

// shouldConvertFields determines whether field conversion is needed based on visualization type.
func shouldConvertFields(visType data.VisType) bool {
	return visType != data.VisTypeTrace && visType != data.VisTypeTable && visType != data.VisTypeLogs
}

// convertNullableJSONFields converts all FieldTypeNullableJSON fields in the given frame to string.
func convertNullableJSONFields(frame *data.Frame) error {
	var convertedFields []*data.Field

	for _, field := range frame.Fields {
		if field.Type() == data.FieldTypeJSON {
			newField, err := convertFieldToString(field)
			if err != nil {
				return err
			}
			convertedFields = append(convertedFields, newField)
		} else {
			convertedFields = append(convertedFields, field)
		}
	}

	frame.Fields = convertedFields
	return nil
}

// convertFieldToString creates a new field where JSON values are marshaled into string representations.
func convertFieldToString(field *data.Field) (*data.Field, error) {
	values := make([]*string, field.Len())
	newField := data.NewField(field.Name, field.Labels, values)
	newField.SetConfig(field.Config)

	for i := 0; i < field.Len(); i++ {
		val, _ := field.At(i).(*json.RawMessage)
		if val == nil {
			newField.Set(i, nil)
		} else {
			bytes, err := val.MarshalJSON()
			if err != nil {
				return nil, err
			}
			sVal := string(bytes)
			newField.Set(i, &sVal)
		}
	}

	return newField, nil
}

func extractForwardedHeadersFromMessage(message json.RawMessage) (map[string]string, error) {
	// An example of the message we're trying to parse:
	// {
	//   "grafana-http-headers": {
	//     "x-grafana-org-id": ["12345"],
	//     "x-grafana-user": ["admin"]
	//   }
	// }
	if len(message) == 0 {
		message = []byte("{}")
	}

	messageArgs := make(map[string]interface{})
	err := json.Unmarshal(message, &messageArgs)
	if err != nil {
		backend.Logger.Warn(fmt.Sprintf("Failed to apply headers: %s", err.Error()))
		return nil, errors.New("couldn't parse message as args")
	}

	httpHeaders := make(map[string]string)
	if grafanaHttpHeaders, ok := messageArgs[sqlds.HeaderKey]; ok {
		fwdHeaders, ok := grafanaHttpHeaders.(map[string]interface{})
		if !ok {
			return nil, errors.New("couldn't parse grafana HTTP headers")
		}

		for k, v := range fwdHeaders {
			anyHeadersArr, ok := v.([]interface{})
			if !ok {
				return nil, fmt.Errorf("couldn't parse header %s as an array", k)
			}

			strHeadersArr := make([]string, len(anyHeadersArr))
			for ind, val := range anyHeadersArr {
				strHeadersArr[ind] = val.(string)
			}

			httpHeaders[k] = strings.Join(strHeadersArr, ",")
		}
	}

	return httpHeaders, nil
}

func mergeOpenTelemetryLabels(frame *data.Frame) error {
	var attrFields []*data.Field
	for _, field := range frame.Fields {
		if field.Name == "labels" {
			return nil
		}

		if field.Type() != data.FieldTypeJSON {
			continue
		}

		if field.Name == "ResourceAttributes" || field.Name == "ScopeAttributes" || field.Name == "LogAttributes" {
			attrFields = append(attrFields, field)
		}
	}

	if len(attrFields) == 0 {
		return nil
	}

	rowLen, err := frame.RowLen()
	if err != nil {
		return err
	}

	allLabelsValues := make([]map[string]any, rowLen)

	for _, field := range attrFields {
		for j := 0; j < rowLen; j++ {
			currentVal := allLabelsValues[j]
			if currentVal == nil {
				currentVal = make(map[string]any)
			}

			val := field.At(j).(json.RawMessage)
			if val != nil {
				var valMap map[string]any
				err := json.Unmarshal(val, &valMap)
				if err != nil {
					return err
				}

				assignFlattenedPath(currentVal, field.Name, "", valMap)

				allLabelsValues[j] = currentVal
			}
		}
	}

	allLabelsValuesJSON := make([]json.RawMessage, rowLen)
	for i, value := range allLabelsValues {
		valueJSON, err := json.Marshal(value)
		if err != nil {
			return err
		}

		allLabelsValuesJSON[i] = valueJSON
	}
	allLabels := data.NewField("labels", make(data.Labels), allLabelsValuesJSON)

	filteredFields := make([]*data.Field, 0, len(frame.Fields)-len(attrFields))
	for _, field := range frame.Fields {
		if field.Name == "ResourceAttributes" || field.Name == "ScopeAttributes" || field.Name == "LogAttributes" {
			continue
		}

		filteredFields = append(filteredFields, field)
	}
	filteredFields = append(filteredFields, allLabels)
	frame.Fields = filteredFields

	return nil
}

// assignFlattenedPath will flatten a nested map into a map with top level keys separated by dots.
func assignFlattenedPath(flatMap map[string]any, pathPrefix, pathKey string, pathValue any) {
	fullPath := fmt.Sprintf("%s.%s", pathPrefix, pathKey)
	if pathKey == "" {
		fullPath = pathPrefix
	}

	nestedMap, ok := pathValue.(map[string]any)
	if !ok {
		flatMap[fullPath] = pathValue
		return
	}

	for k, v := range nestedMap {
		assignFlattenedPath(flatMap, fullPath, k, v)
	}
}
