import React, { useCallback, useMemo } from 'react';
import { AnnotationQuery, AnnotationSupport, GrafanaTheme2, QueryEditorProps } from '@grafana/data';
import { Box, InlineField, InlineFormLabel, Select, Text, TextArea, useStyles2 } from '@grafana/ui';
import { css } from '@emotion/css';
import { Datasource } from './CHDatasource';
import { escapeIdentifier, getTableIdentifier } from './sqlGenerator';
import { CHQuery, CHSqlQuery, EditorType } from 'types/sql';
import { CHConfig } from 'types/config';
import { SchemaPicker, SchemaPickerValue } from 'components/queryBuilder/SchemaPicker';
import useColumns from 'hooks/useColumns';
import { TableColumn } from 'types/queryBuilder';

/** Annotation preset types. */
type AnnotationPreset = 'custom' | 'change_detection';

/**
 * Builder state for the change-detection preset: a schema selection, the watched
 * column's type (so a Map column can require a key before generating), and a
 * group-by column.
 */
type ChangeDetectionState = SchemaPickerValue & { groupBy?: string; columnType?: string };

/** Annotation query extended with the builder state the editor needs to round-trip. */
interface CHAnnotationQuery extends AnnotationQuery<CHQuery> {
  preset?: AnnotationPreset;
  changeDetection?: ChangeDetectionState;
  // Custom SQL stashed when entering Change Detection, restored on return so a
  // hand-written query is not lost by the round trip.
  customSql?: string;
}

/** Props Grafana passes to an annotation QueryEditor (the base props plus annotation-specific ones). */
type AnnotationEditorProps = QueryEditorProps<Datasource, CHQuery, CHConfig> & {
  annotation?: CHAnnotationQuery;
  onAnnotationChange?: (annotation: CHAnnotationQuery) => void;
};

const ANNOTATION_REF_ID = 'annotation';

/** Minimal defaults used only when Grafana mounts the editor without an existing annotation. */
const DEFAULT_ANNOTATION: CHAnnotationQuery = { name: '', enable: true, iconColor: 'red' };

/** Shown in the generated-SQL box until the builder has enough to produce a query. */
const CHANGE_DETECTION_PLACEHOLDER = '-- Select a table and column above to generate the change detection query';

/**
 * Escape a value for use inside a single-quoted ClickHouse string literal.
 * Backslashes and single quotes are the only characters that can break out of
 * the literal. There is no exported string-literal escaper in sqlGenerator
 * (escapeValue is unexported and bails out on special characters), so this
 * stays local and small.
 */
const escapeStringContent = (value: string): string => value.replace(/\\/g, '\\\\').replace(/'/g, "\\'");

/** Build the SQL annotation target, preserving the existing refId and plugin version. */
const buildTarget = (existing: Partial<CHQuery> | undefined, rawSql: string): CHSqlQuery => ({
  pluginVersion: existing?.pluginVersion ?? '',
  editorType: EditorType.SQL,
  rawSql,
  refId: existing?.refId || ANNOTATION_REF_ID,
});

/**
 * Resolve the default database and table for the change-detection preset.
 * Prefers the traces OTel config, then the single-table config when it is
 * configured for traces, then the general default database with the
 * conventional otel_traces table. This adapts to both all-databases and
 * single-table datasources.
 */
export function resolveTraceSchema(datasource: Datasource): { database: string; table: string } {
  const { jsonData } = datasource.settings;
  const singleTable =
    jsonData.configMode === 'single-table' && jsonData.signalType === 'traces'
      ? datasource.getDefaultTable()
      : undefined;
  return {
    database: datasource.getDefaultTraceDatabase() || datasource.getDefaultDatabase(),
    table: datasource.getDefaultTraceTable() || singleTable || 'otel_traces',
  };
}

/**
 * Generate the change-detection SQL from builder selections.
 * Per 30-second bucket take the dominant value (topK(1)) so a service running
 * two versions at once (canary, rolling deploy, multiple replicas) does not
 * flap between them, then use lagInFrame() to detect transitions per group,
 * including rollbacks (v1.0 -> v1.1 -> v1.0 produces three annotations). The
 * outer prev_version != '' guard drops each group's first bucket in the window,
 * where lagInFrame() returns '' and would otherwise mark every group at the
 * left edge of the dashboard range.
 * Identifiers are escaped; the watched map key is emitted as a quoted string literal.
 */
export function generateChangeDetectionSQL(opts: ChangeDetectionState): string {
  const { database, table, column, mapKey, groupBy, columnType } = opts;
  if (!table || !column) {
    return CHANGE_DETECTION_PLACEHOLDER;
  }
  // A Map column is only usable once a key is chosen: without one the generated
  // query would compare the whole Map to '' and ClickHouse rejects it (code 27).
  // Wait for the key rather than emitting a query that cannot run.
  if (columnType?.startsWith('Map(') && !mapKey) {
    return CHANGE_DETECTION_PLACEHOLDER;
  }

  const fullTable = getTableIdentifier(database || '', table);
  const columnExpr = mapKey
    ? `${escapeIdentifier(column)}['${escapeStringContent(mapKey)}']`
    : escapeIdentifier(column);
  const groupByCol = escapeIdentifier(groupBy || 'ServiceName');
  const displayLabel = escapeStringContent(mapKey ? `${column}.${mapKey}` : column);

  return [
    'SELECT',
    '  time,',
    `  ${groupByCol} AS tags,`,
    `  concat(${groupByCol}, ': ${displayLabel} changed to ', version,`,
    `    if(prev_version != '', concat(' (was ', prev_version, ')'), '')) AS text,`,
    `  '${displayLabel} change' AS title`,
    'FROM (',
    '  SELECT',
    '    toStartOfInterval(Timestamp, INTERVAL 30 second) AS time,',
    `    ${groupByCol},`,
    `    topK(1)(${columnExpr})[1] AS version,`,
    `    lagInFrame(topK(1)(${columnExpr})[1])`,
    `      OVER (PARTITION BY ${groupByCol} ORDER BY time) AS prev_version`,
    `  FROM ${fullTable}`,
    '  WHERE $__timeFilter(Timestamp)',
    `    AND ${columnExpr} != ''`,
    `  GROUP BY ${groupByCol}, time`,
    `  ORDER BY ${groupByCol}, time`,
    ')',
    "WHERE prev_version != '' AND prev_version != version",
    'ORDER BY time',
  ].join('\n');
}

/**
 * Build the Group By options for the change-detection builder. ServiceName leads
 * (the OTel convention and the default), followed by columns that make sense to
 * group by: Map columns, the timestamp, the watched column itself, and a duplicate
 * ServiceName are excluded. A saved group-by that the filter would drop (for
 * example a Map or the timestamp from an older query) is appended so the Select
 * shows the real value instead of rendering blank while the SQL still references it.
 */
export function buildGroupByOptions(
  columns: readonly TableColumn[],
  watchColumn: string | undefined,
  savedGroupBy: string | undefined
): Array<{ label: string; value: string }> {
  const options = [
    { label: 'ServiceName', value: 'ServiceName' },
    ...columns
      .filter(
        (c) =>
          !c.type.startsWith('Map(') && c.name !== 'Timestamp' && c.name !== 'ServiceName' && c.name !== watchColumn
      )
      .map((c) => ({ label: c.name, value: c.name })),
  ];
  if (savedGroupBy && !options.some((o) => o.value === savedGroupBy)) {
    options.push({ label: savedGroupBy, value: savedGroupBy });
  }
  return options;
}

const PRESET_OPTIONS = [
  { label: 'Custom SQL', value: 'custom' as AnnotationPreset, description: 'Write your own annotation query' },
  {
    label: 'Change Detection',
    value: 'change_detection' as AnnotationPreset,
    description: 'Detect when a column value changes (deployments, config changes, rollbacks)',
    icon: 'rocket',
  },
];

/** Annotation query editor with a preset selector and a change-detection builder. */
const AnnotationQueryEditor = (props: AnnotationEditorProps) => {
  const { annotation, onAnnotationChange, datasource } = props;
  const anno: CHAnnotationQuery = annotation ?? DEFAULT_ANNOTATION;
  const preset = anno.preset || 'custom';
  const cd: ChangeDetectionState = useMemo(() => anno.changeDetection || {}, [anno.changeDetection]);
  const styles = useStyles2(getStyles);

  // Reuse the shared column hook for the group-by picker.
  const columns = useColumns(datasource, cd.database || '', cd.table || '');

  const updateChangeDetection = useCallback(
    (updates: Partial<ChangeDetectionState>) => {
      if (!onAnnotationChange) {
        return;
      }
      const newCd = { ...cd, ...updates };
      onAnnotationChange({
        ...anno,
        preset: 'change_detection',
        changeDetection: newCd,
        target: buildTarget(anno.target, generateChangeDetectionSQL(newCd)),
      });
    },
    [anno, cd, onAnnotationChange]
  );

  const onSchemaChange = useCallback(
    (schemaValue: SchemaPickerValue) => {
      // Carry the watched column's type so the generator can require a Map key.
      const columnType = columns.find((c) => c.name === schemaValue.column)?.type;
      updateChangeDetection({ ...schemaValue, columnType });
    },
    [updateChangeDetection, columns]
  );

  const onPresetChange = useCallback(
    (value: AnnotationPreset) => {
      if (!onAnnotationChange) {
        return;
      }
      if (value === 'change_detection') {
        // Seed sensible deployment defaults so the builder opens populated with a
        // working query (instead of an empty builder and a placeholder), and stash
        // the current Custom SQL so switching back restores it.
        const seeded: ChangeDetectionState =
          cd.table && cd.column
            ? cd
            : {
                ...resolveTraceSchema(datasource),
                column: 'ResourceAttributes',
                columnType: 'Map(String, String)',
                mapKey: 'service.version',
                groupBy: 'ServiceName',
              };
        onAnnotationChange({
          ...anno,
          preset: value,
          customSql: anno.target?.rawSql ?? '',
          changeDetection: seeded,
          target: buildTarget(anno.target, generateChangeDetectionSQL(seeded)),
        });
      } else {
        // Restore the Custom SQL stashed when Change Detection was entered.
        onAnnotationChange({
          ...anno,
          preset: value,
          target: buildTarget(anno.target, anno.customSql ?? ''),
        });
      }
    },
    [anno, cd, datasource, onAnnotationChange]
  );

  const onSqlChange = useCallback(
    (e: React.ChangeEvent<HTMLTextAreaElement>) => {
      if (!onAnnotationChange) {
        return;
      }
      onAnnotationChange({
        ...anno,
        target: buildTarget(anno.target, e.currentTarget.value),
      });
    },
    [anno, onAnnotationChange]
  );

  const groupByOptions = buildGroupByOptions(columns, cd.column, cd.groupBy);

  return (
    <div>
      <InlineField
        label={
          <InlineFormLabel width={10} tooltip="Select an annotation preset or write custom SQL">
            Annotation Type
          </InlineFormLabel>
        }
        style={{ marginBottom: 8 }}
      >
        <Select
          width={40}
          options={PRESET_OPTIONS}
          value={preset}
          onChange={(v) => onPresetChange(v.value || 'custom')}
        />
      </InlineField>

      {preset === 'change_detection' && (
        <>
          <SchemaPicker
            datasource={datasource}
            value={cd}
            onChange={onSchemaChange}
            level="mapKey"
            labels={{ column: 'Watch Column', mapKey: 'Map Key' }}
          />

          {cd.column && (
            <InlineField
              label={
                <InlineFormLabel
                  width={10}
                  tooltip="Group changes by this column. Each unique value is tracked independently."
                >
                  Group By
                </InlineFormLabel>
              }
            >
              <Select
                width={30}
                options={groupByOptions}
                value={cd.groupBy || 'ServiceName'}
                onChange={(v) => updateChangeDetection({ groupBy: v.value || 'ServiceName' })}
              />
            </InlineField>
          )}
        </>
      )}

      <InlineField label={<InlineFormLabel width={10}>SQL Query</InlineFormLabel>} grow shrink>
        <Box>
          <TextArea
            className={styles.sqlInput}
            rows={8}
            value={anno.target?.rawSql || ''}
            onChange={onSqlChange}
            placeholder="SELECT Timestamp AS time, Body AS text, ServiceName AS tags FROM otel_logs WHERE $__timeFilter(Timestamp)"
          />
          <Box marginTop={0.5} marginBottom={1}>
            <Text color="secondary" variant="bodySmall">
              {preset === 'change_detection'
                ? 'Annotations appear when the watched value changes per group, including rollbacks.'
                : 'Return columns: time (required), text, title, tags. Standard Grafana annotation mapping.'}
            </Text>
          </Box>
        </Box>
      </InlineField>
    </div>
  );
};

const getStyles = (theme: GrafanaTheme2) => ({
  sqlInput: css({
    fontFamily: theme.typography.fontFamilyMonospace,
    fontSize: theme.typography.bodySmall.fontSize,
  }),
});

/** Build the AnnotationSupport object wired into the datasource. */
export function createAnnotationSupport(datasource: Datasource): AnnotationSupport<CHQuery> {
  return {
    prepareAnnotation: (json: AnnotationQuery<CHQuery>): AnnotationQuery<CHQuery> => {
      // Legacy dashboards stored the SQL as a top-level `rawQuery` string. Migrate
      // it into the modern target shape once. `rawQuery` is read via the
      // AnnotationQuery index signature, so no cast is needed.
      const legacyRawQuery: string | undefined = json?.rawQuery;
      const prepared: CHAnnotationQuery =
        legacyRawQuery && !json?.target?.rawSql ? { ...json, target: buildTarget(json.target, legacyRawQuery) } : json;

      // Dashboards may carry a preset id unknown to this editor (early
      // bundled dashboards shipped 'deployment_detection'). Migrate it to
      // 'custom' and seed the customSql stash from the shipped SQL, otherwise
      // the preset round trip would overwrite the query with an empty string.
      const preset: string | undefined = prepared.preset;
      if (preset !== undefined && preset !== 'custom' && preset !== 'change_detection') {
        return {
          ...prepared,
          preset: 'custom',
          customSql: prepared.customSql || prepared.target?.rawSql || legacyRawQuery || '',
        };
      }
      return prepared;
    },

    getDefaultQuery: (): Partial<CHQuery> => ({
      // Open in Custom SQL mode (the editor's default preset) with an empty query so
      // the default editor mode and the default query agree. Choosing Change
      // Detection seeds a populated deployment-change builder.
      editorType: EditorType.SQL,
      rawSql: '',
      refId: ANNOTATION_REF_ID,
    }),

    QueryEditor: AnnotationQueryEditor,
  };
}
