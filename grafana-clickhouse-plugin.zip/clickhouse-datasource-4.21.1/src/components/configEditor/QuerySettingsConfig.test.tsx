import React from 'react';
import { render, fireEvent } from '@testing-library/react';
import { QuerySettingsConfig } from './QuerySettingsConfig';
import allLabels from 'labels';

const noop = () => {};

const baseProps = {
  onConnMaxIdleConnsChange: noop,
  onConnMaxLifetimeChange: noop,
  onConnMaxOpenConnsChange: noop,
  onDialTimeoutChange: noop,
  onQueryTimeoutChange: noop,
  onRowCapacityHintChange: noop,
  onValidateSqlChange: noop,
  onEnableMapKeysDiscoveryChange: noop,
};

describe('QuerySettingsConfig', () => {
  it('should render', () => {
    const result = render(
      <QuerySettingsConfig
        {...baseProps}
        connMaxLifetime={'5'}
        dialTimeout={'5'}
        maxIdleConns={'5'}
        maxOpenConns={'5'}
        queryTimeout={'5'}
        rowCapacityHint={'5000'}
        validateSql={true}
      />
    );
    expect(result.container.firstChild).not.toBeNull();
  });

  it('should call onDialTimeout when changed', () => {
    const onDialTimeout = jest.fn();
    const result = render(<QuerySettingsConfig {...baseProps} onDialTimeoutChange={onDialTimeout} />);
    expect(result.container.firstChild).not.toBeNull();

    const input = result.getByPlaceholderText(allLabels.components.Config.QuerySettingsConfig.dialTimeout.placeholder);
    expect(input).toBeInTheDocument();
    fireEvent.change(input, { target: { value: '10' } });
    fireEvent.blur(input);
    expect(onDialTimeout).toHaveBeenCalledTimes(1);
    expect(onDialTimeout).toHaveBeenCalledWith(expect.any(Object));
  });

  it('should call onQueryTimeout when changed', () => {
    const onQueryTimeout = jest.fn();
    const result = render(<QuerySettingsConfig {...baseProps} onQueryTimeoutChange={onQueryTimeout} />);
    expect(result.container.firstChild).not.toBeNull();

    const input = result.getByPlaceholderText(allLabels.components.Config.QuerySettingsConfig.queryTimeout.placeholder);
    expect(input).toBeInTheDocument();
    fireEvent.change(input, { target: { value: '10' } });
    fireEvent.blur(input);
    expect(onQueryTimeout).toHaveBeenCalledTimes(1);
    expect(onQueryTimeout).toHaveBeenCalledWith(expect.any(Object));
  });

  it('should call onRowCapacityHintChange when changed', () => {
    const onRowCapacityHintChange = jest.fn();
    const result = render(<QuerySettingsConfig {...baseProps} onRowCapacityHintChange={onRowCapacityHintChange} />);
    expect(result.container.firstChild).not.toBeNull();

    const input = result.getByPlaceholderText(
      allLabels.components.Config.QuerySettingsConfig.rowCapacityHint.placeholder
    );
    expect(input).toBeInTheDocument();
    fireEvent.change(input, { target: { value: '50000' } });
    fireEvent.blur(input);
    expect(onRowCapacityHintChange).toHaveBeenCalledTimes(1);
    expect(onRowCapacityHintChange).toHaveBeenCalledWith(expect.any(Object));
  });

  it('should call onValidateSqlChange when changed', () => {
    const onValidateSqlChange = jest.fn();
    const result = render(<QuerySettingsConfig {...baseProps} onValidateSqlChange={onValidateSqlChange} />);
    expect(result.container.firstChild).not.toBeNull();

    // Two switches: validateSql first, enableMapKeysDiscovery second.
    const inputs = result.getAllByRole('checkbox');
    fireEvent.click(inputs[0]);
    expect(onValidateSqlChange).toHaveBeenCalledTimes(1);
    expect(onValidateSqlChange).toHaveBeenCalledWith(expect.any(Object));
  });

  it('should call onEnableMapKeysDiscoveryChange when changed', () => {
    const onEnableMapKeysDiscoveryChange = jest.fn();
    const result = render(
      <QuerySettingsConfig {...baseProps} onEnableMapKeysDiscoveryChange={onEnableMapKeysDiscoveryChange} />
    );
    const inputs = result.getAllByRole('checkbox');
    fireEvent.click(inputs[1]);
    expect(onEnableMapKeysDiscoveryChange).toHaveBeenCalledTimes(1);
    expect(onEnableMapKeysDiscoveryChange).toHaveBeenCalledWith(expect.any(Object));
  });

  it('should call onConnMaxIdleConnsChange when changed', () => {
    const onConnMaxIdleConnsChange = jest.fn();
    const result = render(<QuerySettingsConfig {...baseProps} onConnMaxIdleConnsChange={onConnMaxIdleConnsChange} />);
    expect(result.container.firstChild).not.toBeNull();

    const input = result.getByPlaceholderText(allLabels.components.Config.QuerySettingsConfig.maxIdleConns.placeholder);
    expect(input).toBeInTheDocument();
    fireEvent.change(input, { target: { value: '10' } });
    fireEvent.blur(input);
    expect(onConnMaxIdleConnsChange).toHaveBeenCalledTimes(1);
    expect(onConnMaxIdleConnsChange).toHaveBeenCalledWith(expect.any(Object));
  });

  it('should call onConnMaxLifetimeChange when changed', () => {
    const onConnMaxLifetimeChange = jest.fn();
    const result = render(<QuerySettingsConfig {...baseProps} onConnMaxLifetimeChange={onConnMaxLifetimeChange} />);
    expect(result.container.firstChild).not.toBeNull();

    const input = result.getByPlaceholderText(
      allLabels.components.Config.QuerySettingsConfig.connMaxLifetime.placeholder
    );
    expect(input).toBeInTheDocument();
    fireEvent.change(input, { target: { value: '10' } });
    fireEvent.blur(input);
    expect(onConnMaxLifetimeChange).toHaveBeenCalledTimes(1);
    expect(onConnMaxLifetimeChange).toHaveBeenCalledWith(expect.any(Object));
  });

  it('should call onConnMaxOpenConnsChange when changed', () => {
    const onConnMaxOpenConnsChange = jest.fn();
    const result = render(<QuerySettingsConfig {...baseProps} onConnMaxOpenConnsChange={onConnMaxOpenConnsChange} />);
    expect(result.container.firstChild).not.toBeNull();

    const input = result.getByPlaceholderText(allLabels.components.Config.QuerySettingsConfig.maxOpenConns.placeholder);
    expect(input).toBeInTheDocument();
    fireEvent.change(input, { target: { value: '10' } });
    fireEvent.blur(input);
    expect(onConnMaxOpenConnsChange).toHaveBeenCalledTimes(1);
    expect(onConnMaxOpenConnsChange).toHaveBeenCalledWith(expect.any(Object));
  });
});
